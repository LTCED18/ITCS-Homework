// Bvinson_Project2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "CFraction.h"
#include <string>

using namespace std;

int main()
{

	/*
	CFraction frac1(1, 2);
	CFraction frac2(3, 5);
	CFraction frac3;
	CFraction frac4;

	frac3 = frac1 / frac2;

	operator<<(cout, frac3);
	*/


	
	system("pause");
	return 0;
}

