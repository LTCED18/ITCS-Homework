#include "pch.h"
#include "CFraction.h"


CFraction::CFraction()
{
}

CFraction::CFraction(int iNumerator, int iDenominator) {
	numerator = iNumerator;
	denominator = iDenominator;
}

CFraction CFraction::operator+(const CFraction& fraction) {
	CFraction tempFraction;


	tempFraction.numerator = (numerator * fraction.denominator) + (fraction.numerator * denominator);
	tempFraction.denominator = (denominator * fraction.denominator);

	return tempFraction;
}

CFraction CFraction::operator-(const CFraction& fraction) {
	CFraction tempFraction;


	tempFraction.numerator = (numerator * fraction.denominator) - (fraction.numerator * denominator);
	tempFraction.denominator = (denominator * fraction.denominator);

	return tempFraction;
}

CFraction CFraction::operator*(const CFraction& fraction) {
	CFraction tempFraction;

	tempFraction.numerator = numerator * fraction.numerator;
	tempFraction.denominator = denominator * fraction.denominator;

	return tempFraction;
}

CFraction CFraction::operator/(const CFraction& fraction) {
	CFraction tempFraction;

	tempFraction.numerator = numerator * fraction.denominator;
	tempFraction.denominator = denominator * fraction.numerator;

	return tempFraction;
}

CFraction CFraction::operator+(const double decimalValue) {
	CFraction tempFraction;
	return tempFraction;
}

CFraction::~CFraction()
{
}
